class Node {
    Book info;
    Node left, right;

    Node(Book x) {
        info = x;
        left = right = null;
    }
}
